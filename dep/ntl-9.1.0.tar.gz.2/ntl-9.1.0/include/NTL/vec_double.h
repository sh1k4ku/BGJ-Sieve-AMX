
#ifndef NTL_vec_double__H
#define NTL_vec_double__H

#include <NTL/vector.h>

NTL_OPEN_NNS

typedef Vec<double> vec_double;

NTL_CLOSE_NNS

#endif
